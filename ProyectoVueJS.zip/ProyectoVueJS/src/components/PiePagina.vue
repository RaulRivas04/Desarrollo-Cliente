<template>
  <footer>
    <p>
      Desarrollado por "Raúl Rivas Ortega".<br />
      Código disponible en <a href="https://github.com/RaulRivas04/Desarrollo-Cliente">GitHub</a>.
    </p>
  </footer>
</template>

<style scoped>
footer {
  text-align: center;
  padding: 10px 0;
  background-color: #2c2c2c;
  color: #aaa;
  font-size: 14px;
}

footer a {
  color: #1abc9c;
  text-decoration: none;
}

footer a:hover {
  text-decoration: underline;
}


</style>
